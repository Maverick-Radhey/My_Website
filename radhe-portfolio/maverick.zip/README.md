# Hailee portfolio webpage

A portfolio web site completely made in html css and js from ground up.

#### Watch it live here - [hailee.netlify.app](https://hailee.netlify.app/)

<br>

## This is how it looks

<br>

### In dark mode

![In dark mode](./preview/hailee-dark.png)

### In light mode

![In light mode](./preview/hailee-light.png)
